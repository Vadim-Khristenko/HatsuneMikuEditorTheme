-- Hatsune Miku Dark: Neovim colorscheme
-- Part of HatsuneMikuEditorTheme. Generated from VS Code canonical palette.
vim.cmd("hi clear")
if vim.fn.exists("syntax_on") == 1 then vim.cmd("syntax reset") end
vim.o.termguicolors = true
vim.o.background = "dark"
vim.g.colors_name = "hatsune-miku"

local c = {
  bg = "#0d0e1a",
  alt = "#0a0b18",
  surface = "#11121f",
  elevated = "#161728",
  linehl = "#131526",
  border = "#1e2035",
  fg = "#ccd6f6",
  muted = "#7079a8",
  faint = "#4a5280",
  linenr = "#3d4470",
  accent = "#39c5bb",
  hover = "#00e5d6",
  comment = "#4a5280",
  comment_doc = "#5a6490",
  keyword = "#ff6a88",
  operator = "#7399ff",
  fn = "#39c5bb",
  str = "#ffbf12",
  escape = "#ff708e",
  num = "#cb87ff",
  type = "#7399ff",
  prop = "#97b2fb",
  param = "#e2ad81",
  builtin = "#ff708e",
  attr = "#cb87ff",
  decor = "#ffbf12",
  err = "#ff6a88",
  warn = "#ffbf12",
  info = "#7399ff",
  hint = "#7079a8",
  git_add = "#39c5bb",
  git_mod = "#7399ff",
  git_del = "#ff6a88",
  invisible = "#2a2f50",
}
local hi = vim.api.nvim_set_hl
local H = function(g, o) hi(0, g, o) end
local L = function(to, from) hi(0, to, { link = from }) end

-- Base UI
H("Normal", { fg = c.fg, bg = c.bg })
H("NormalFloat", { fg = c.fg, bg = c.elevated })
H("FloatBorder", { fg = c.border, bg = c.elevated })
H("FloatTitle", { fg = c.accent, bg = c.elevated, bold = true })
H("CursorLine", { bg = c.linehl })
H("CursorColumn", { bg = c.linehl })
H("CursorLineNr", { fg = c.accent, bold = true })
H("LineNr", { fg = c.linenr })
H("SignColumn", { bg = c.bg })
H("VertSplit", { fg = c.border })
H("WinSeparator", { fg = c.border })
H("Visual", { bg = c.accent .. "22" })
H("Search", { bg = c.accent .. "44" })
H("IncSearch", { fg = c.bg, bg = c.hover })
H("CurSearch", { fg = c.bg, bg = c.hover })
H("Substitute", { fg = c.bg, bg = c.keyword })
H("Pmenu", { fg = c.fg, bg = c.elevated })
H("PmenuSel", { fg = c.accent, bg = c.surface })
H("PmenuSbar", { bg = c.elevated })
H("PmenuThumb", { bg = c.border })
H("WildMenu", { fg = c.accent, bg = c.surface })
H("Folded", { fg = c.muted, bg = c.surface })
H("FoldColumn", { fg = c.linenr, bg = c.bg })
H("MatchParen", { fg = c.accent, bg = c.accent .. "22", bold = true })
H("StatusLine", { fg = c.fg, bg = c.surface })
H("StatusLineNC", { fg = c.muted, bg = c.surface })
H("TabLine", { fg = c.muted, bg = c.alt })
H("TabLineSel", { fg = c.fg, bg = c.surface })
H("TabLineFill", { bg = c.alt })
H("Title", { fg = c.accent, bold = true })
H("Directory", { fg = c.accent })
H("EndOfBuffer", { fg = c.bg })
H("NonText", { fg = c.faint })
H("Whitespace", { fg = c.invisible })
H("Conceal", { fg = c.muted })
H("ColorColumn", { bg = c.linehl })
H("ErrorMsg", { fg = c.err })
H("WarningMsg", { fg = c.warn })
H("ModeMsg", { fg = c.muted })
H("MoreMsg", { fg = c.accent })
H("Question", { fg = c.accent })
H("SpecialKey", { fg = c.faint })
H("Underlined", { underline = true })
H("Ignore", { fg = c.faint })
H("Todo", { fg = c.keyword, bold = true })
H("Error", { fg = c.err })
H("QuickFixLine", { bg = c.surface })

H("DiffAdd", { bg = c.git_add .. "0d" })
H("DiffChange", { bg = c.git_mod .. "0d" })
H("DiffDelete", { bg = c.git_del .. "0d" })
H("DiffText", { fg = c.bg, bg = c.git_mod })
H("Added", { fg = c.git_add })
H("Removed", { fg = c.git_del })
H("Changed", { fg = c.git_mod })
H("GitSignsAdd", { fg = c.git_add })
H("GitSignsChange", { fg = c.git_mod })
H("GitSignsDelete", { fg = c.git_del })

H("SpellBad", { fg = c.err, undercurl = true, sp = c.err })
H("SpellCap", { fg = c.info, undercurl = true, sp = c.info })
H("SpellRare", { fg = c.num, undercurl = true, sp = c.num })
H("SpellLocal", { fg = c.git_add, undercurl = true, sp = c.git_add })

H("Comment", { fg = c.comment, italic = true })
H("SpecialComment", { fg = c.comment_doc, italic = true })
H("Constant", { fg = c.num })
H("String", { fg = c.str })
H("Character", { fg = c.str })
H("Number", { fg = c.num })
H("Boolean", { fg = c.num, bold = true })
H("Float", { fg = c.num })
H("Identifier", { fg = c.fg })
H("Function", { fg = c.fn })
H("Statement", { fg = c.keyword })
H("Conditional", { fg = c.keyword })
H("Repeat", { fg = c.keyword })
H("Label", { fg = c.type })
H("Operator", { fg = c.operator })
H("Keyword", { fg = c.keyword })
H("Exception", { fg = c.keyword, bold = true })
H("PreProc", { fg = c.decor })
H("Include", { fg = c.decor })
H("Define", { fg = c.decor })
H("Macro", { fg = c.decor })
H("PreCondit", { fg = c.decor })
H("Type", { fg = c.type })
H("StorageClass", { fg = c.keyword })
H("Structure", { fg = c.keyword })
H("Typedef", { fg = c.type, italic = true })
H("Special", { fg = c.escape })
H("SpecialChar", { fg = c.escape })
H("Tag", { fg = c.keyword })
H("Delimiter", { fg = c.muted })

L("@comment", "Comment")
H("@comment.documentation", { fg = c.comment_doc, italic = true })
L("@keyword", "Statement")
H("@keyword.function", { fg = c.keyword, italic = true })
L("@keyword.operator", "Operator")
H("@keyword.return", { fg = c.keyword, bold = true })
L("@operator", "Operator")
L("@string", "String")
L("@string.escape", "SpecialChar")
H("@string.regex", { fg = c.hover })
L("@number", "Number")
L("@boolean", "Boolean")
L("@constant", "Number")
H("@constant.builtin", { fg = c.builtin, italic = true })
L("@function", "Function")
H("@function.builtin", { fg = c.hover, italic = true })
L("@function.call", "Function")
L("@method", "Function")
H("@constructor", { fg = c.accent })
L("@type", "Type")
H("@type.builtin", { fg = c.type, italic = true })
H("@property", { fg = c.prop })
L("@field", "@property")
H("@parameter", { fg = c.param })
L("@variable", "Identifier")
H("@variable.builtin", { fg = c.builtin, italic = true })
L("@label", "Label")
L("@tag", "Tag")
H("@tag.attribute", { fg = c.attr })
L("@punctuation.bracket", "Delimiter")
L("@punctuation.delimiter", "Delimiter")
H("@punctuation.special", { fg = c.operator })
L("@text.literal", "String")
H("@markup.heading", { fg = c.accent, bold = true })
H("Italic", { italic = true })
H("Bold", { bold = true })
H("@markup.link", { fg = c.accent, underline = true })
L("@markup.list", "Directory")
L("@diff.plus", "Added")
L("@diff.minus", "Removed")
L("@diff.delta", "Changed")

H("DiagnosticError", { fg = c.err })
H("DiagnosticWarn", { fg = c.warn })
H("DiagnosticInfo", { fg = c.info })
H("DiagnosticHint", { fg = c.hint })
H("DiagnosticOk", { fg = c.git_add })
H("DiagnosticUnderlineError", { undercurl = true, sp = c.err })
H("DiagnosticUnderlineWarn", { undercurl = true, sp = c.warn })
H("DiagnosticUnderlineInfo", { undercurl = true, sp = c.info })
H("DiagnosticUnderlineHint", { undercurl = true, sp = c.hint })
L("LspDiagnosticsDefaultError", "DiagnosticError")
L("LspDiagnosticsDefaultWarning", "DiagnosticWarn")
L("LspDiagnosticsDefaultInformation", "DiagnosticInfo")
L("LspDiagnosticsDefaultHint", "DiagnosticHint")

L("@lsp.type.namespace", "Type")
L("@lsp.type.type", "Type")
L("@lsp.type.class", "Type")
L("@lsp.type.enum", "Number")
L("@lsp.type.interface", "Type")
L("@lsp.type.struct", "Type")
L("@lsp.type.parameter", "@parameter")
L("@lsp.type.variable", "Identifier")
L("@lsp.type.property", "@property")
L("@lsp.type.macro", "PreProc")
L("@lsp.type.function", "Function")
L("@lsp.type.method", "Function")
L("@lsp.type.keyword", "Keyword")
L("@lsp.type.comment", "Comment")
L("@lsp.type.string", "String")
L("@lsp.type.number", "Number")
L("@lsp.type.operator", "Operator")

-- Terminal ANSI
vim.g["terminal_color_0"] = "#1a1b2e"
vim.g["terminal_color_1"] = "#ff6a88"
vim.g["terminal_color_2"] = "#39c5bb"
vim.g["terminal_color_3"] = "#ffbf12"
vim.g["terminal_color_4"] = "#7399ff"
vim.g["terminal_color_5"] = "#cb87ff"
vim.g["terminal_color_6"] = "#00e5d6"
vim.g["terminal_color_7"] = "#ccd6f6"
vim.g["terminal_color_8"] = "#4a5280"
vim.g["terminal_color_9"] = "#ff708e"
vim.g["terminal_color_10"] = "#5df5e8"
vim.g["terminal_color_11"] = "#f9d561"
vim.g["terminal_color_12"] = "#97b2fb"
vim.g["terminal_color_13"] = "#d5a2fb"
vim.g["terminal_color_14"] = "#40f0e8"
vim.g["terminal_color_15"] = "#ffffff"
